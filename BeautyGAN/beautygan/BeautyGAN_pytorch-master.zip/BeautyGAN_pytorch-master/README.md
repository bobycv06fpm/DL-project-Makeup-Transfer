# BeautyGAN

Official implementation of ACM MM 2018 paper: "BeautyGAN: Instance-level Facial Makeup Transfer with Deep Generative Adversarial Network"

Dataset can be found in project page: http://colalab.org/projects/BeautyGAN


## still in construction
